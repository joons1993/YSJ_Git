package com.example.joons.project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.Button;


/**
 * Created by joons on 2018-10-17.
 */

public class AvailableButton extends AppCompatActivity {
    Button available_Button;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parkinglot_list);

        available_Button = (Button) findViewById(R.id.available_button);


    }
}
