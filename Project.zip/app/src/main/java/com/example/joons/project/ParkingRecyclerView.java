package com.example.joons.project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Created by joons on 2018-10-22.
 */

public class ParkingRecyclerView extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parkinglot_list);

        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        ArrayList<ParkingInfo> ParkingInfoArrayList = new ArrayList<>();
        ParkingInfoArrayList.add(new ParkingInfo(R.drawable.baseline_local_parking_black_18dp, "IT대학"));
        ParkingInfoArrayList.add(new ParkingInfo(R.drawable.baseline_local_parking_black_18dp, "글로벌경상관(지하주차장)"));
        ParkingInfoArrayList.add(new ParkingInfo(R.drawable.baseline_local_parking_black_18dp, "국제대학"));
        ParkingInfoArrayList.add(new ParkingInfo(R.drawable.baseline_local_parking_black_18dp, "미래혁신관(지하주차장)"));
        ParkingInfoArrayList.add(new ParkingInfo(R.drawable.baseline_local_parking_black_18dp,"인문사회대학"));

        MyAdapter myAdapter = new MyAdapter(ParkingInfoArrayList);
        mRecyclerView.setAdapter(myAdapter);
    }
}