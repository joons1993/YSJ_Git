package com.example.joons.project;

/**
 * Created by joons on 2018-10-17.
 */

public class ParkingInfo {
    public int drawableId;
    public String college;

    public ParkingInfo(int drawableId, String college){
        this.drawableId = drawableId;
        this.college = college;
    }
}
